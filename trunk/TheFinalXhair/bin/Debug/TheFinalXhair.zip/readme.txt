CS: go must have the following:
1) cl_crosshair 0
2) full screen borderless window.

You must run this program after you start cs:go.
